<?php echo e($slot); ?>

<?php /**PATH C:\Users\kabos\OneDrive\Desktop\react\blank-web\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>