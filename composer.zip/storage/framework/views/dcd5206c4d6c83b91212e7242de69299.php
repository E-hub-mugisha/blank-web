<!-- Star Clients Area
    ============================================= -->
<div class="clients-area default-padding-bottom">
    <div class="container">
        <div class="row align-center">
            <div class="col-lg-12">
                <div class="partner-carousel justify-items-center owl-carousel owl-theme">
                    <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="../assets/img/partners/<?php echo e($partner->image); ?>" alt="<?php echo e($partner->partner_name); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Clients Area --><?php /**PATH C:\Users\kabos\OneDrive\Desktop\react\blank-web\resources\views/components/clients.blade.php ENDPATH**/ ?>