<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Blank')); ?></title>
        <link rel="shortcut icon" href="<?php echo e(asset('assets/img/fav.png')); ?>" type="image/x-icon">
        <link rel="icon" href="<?php echo e(asset('assets/img/fav.png')); ?>" type="image/x-icon" />

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Bootstrap -->
        <link href="<?php echo e(asset('admin/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="<?php echo e(asset('admin/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
        <!-- NProgress -->
        <link href="<?php echo e(asset('admin/vendors/nprogress/nprogress.css')); ?>" rel="stylesheet">
        <!-- iCheck -->
        <link href="<?php echo e(asset('admin/vendors/iCheck/skins/flat/green.css')); ?>" rel="stylesheet">
        <!-- bootstrap-wysiwyg -->
        <link href="<?php echo e(asset('admin/vendors/google-code-prettify/bin/prettify.min.css')); ?>" rel="stylesheet">
        <!-- Select2 -->
        <link href="<?php echo e(asset('admin/vendors/select2/dist/css/select2.min.css')); ?>" rel="stylesheet">
        <!-- Switchery -->
        <link href="<?php echo e(asset('admin/vendors/switchery/dist/switchery.min.css')); ?>" rel="stylesheet">
        <!-- starrr -->
        <link href="<?php echo e(asset('admin/vendors/starrr/dist/starrr.css')); ?>" rel="stylesheet">
        <!-- bootstrap-daterangepicker -->
        <link href="<?php echo e(asset('admin/vendors/bootstrap-daterangepicker/daterangepicker.css')); ?>" rel="stylesheet">
        <!-- bootstrap-progressbar -->
        <link href="<?php echo e(asset('admin/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css')); ?>" rel="stylesheet">
        <!-- JQVMap -->
        <link href="<?php echo e(asset('admin/vendors/jqvmap/dist/jqvmap.min.css')); ?>" rel="stylesheet" />
        <!-- bootstrap-daterangepicker -->
        <link href="<?php echo e(asset('admin/vendors/bootstrap-daterangepicker/daterangepicker.css')); ?>" rel="stylesheet">
        <!-- Dropzone.js -->
        <link href="<?php echo e(asset('admin/vendors/dropzone/dist/min/dropzone.min.css')); ?>" rel="stylesheet">
        <!-- Custom Theme Style -->
        <link href="<?php echo e(asset('admin/css/custom.min.css')); ?>" rel="stylesheet">

        <link rel="stylesheet" href="<?php echo e(asset('admin/vendors/summernote/summernote.min.css')); ?>" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

        <!-- Styles -->
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>

<body class="nav-md">
    <div class="container body">
        <div class="main_container">
            <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Page Content -->
            <main>
                <?php echo $__env->yieldContent('content'); ?>
            </main>

            <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>


    <!-- jQuery -->
    <script src="<?php echo e(asset('admin/vendors/jquery/dist/jquery.min.js')); ?>"></script>
    <!-- Bootstrap -->
    <script src="<?php echo e(asset('admin/vendors/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- FastClick -->
    <script src="<?php echo e(asset('admin/vendors/fastclick/lib/fastclick.js')); ?>"></script>
    <!-- NProgress -->
    <script src="<?php echo e(asset('admin/vendors/nprogress/nprogress.js')); ?>"></script>
    <!-- Chart.js -->
    <script src="<?php echo e(asset('admin/vendors/Chart.js/dist/Chart.min.js')); ?>"></script>
    <!-- gauge.js -->
    <script src="<?php echo e(asset('admin/vendors/gauge.js/dist/gauge.min.js')); ?>"></script>
    <!-- bootstrap-progressbar -->
    <script src="<?php echo e(asset('admin/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js')); ?>"></script>
    <!-- iCheck -->
    <script src="<?php echo e(asset('admin/vendors/iCheck/icheck.min.js')); ?>"></script>
    <!-- Skycons -->
    <script src="<?php echo e(asset('admin/vendors/skycons/skycons.js')); ?>"></script>
    <!-- Flot -->
    <script src="<?php echo e(asset('admin/vendors/Flot/jquery.flot.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/Flot/jquery.flot.pie.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/Flot/jquery.flot.time.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/Flot/jquery.flot.stack.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/Flot/jquery.flot.resize.js')); ?>"></script>
    <!-- Flot plugins -->
    <script src="<?php echo e(asset('admin/vendors/flot.orderbars/js/jquery.flot.orderBars.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/flot-spline/js/jquery.flot.spline.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/flot.curvedlines/curvedLines.js')); ?>"></script>
    <!-- DateJS -->
    <script src="<?php echo e(asset('admin/vendors/DateJS/build/date.js')); ?>"></script>
    <!-- JQVMap -->
    <script src="<?php echo e(asset('admin/vendors/jqvmap/dist/jquery.vmap.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/jqvmap/dist/maps/jquery.vmap.world.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js')); ?>"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="<?php echo e(asset('admin/vendors/moment/min/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="<?php echo e(asset('admin/vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/jquery.hotkeys/jquery.hotkeys.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/google-code-prettify/src/prettify.js')); ?>"></script>
    <!-- jQuery Tags Input -->
    <script src="<?php echo e(asset('admin/vendors/jquery.tagsinput/src/jquery.tagsinput.js')); ?>"></script>
    <!-- Switchery -->
    <script src="<?php echo e(asset('admin/vendors/switchery/dist/switchery.min.js')); ?>"></script>
    <!-- Select2 -->
    <script src="<?php echo e(asset('admin/vendors/select2/dist/js/select2.full.min.js')); ?>"></script>
    <!-- Parsley -->
    <script src="<?php echo e(asset('admin/vendors/parsleyjs/dist/parsley.min.js')); ?>"></script>
    <!-- Autosize -->
    <script src="<?php echo e(asset('admin/vendors/autosize/dist/autosize.min.js')); ?>"></script>
    <!-- jQuery autocomplete -->
    <script src="<?php echo e(asset('admin/vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js')); ?>"></script>
    <!-- starrr -->
    <script src="<?php echo e(asset('admin/vendors/starrr/dist/starrr.js')); ?>"></script>
    <!-- Dropzone.js -->
    <script src="<?php echo e(asset('admin/vendors/dropzone/dist/min/dropzone.min.js')); ?>"></script>
    <!-- Custom Theme Scripts -->
    <script src="<?php echo e(asset('admin/js/custom.min.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/vendors/summernote/summernote-bs4.min.js')); ?>"></script>
    <script type="text/javascript">
        $('#summernote').summernote({
            height: 400
        });
    </script>
    <?php echo $__env->yieldPushContent('modals'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html><?php /**PATH C:\Users\kabos\OneDrive\Desktop\react\blank-web\resources\views\layouts\app.blade.php ENDPATH**/ ?>