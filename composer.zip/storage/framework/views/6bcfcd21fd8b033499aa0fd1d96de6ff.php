<div class="pt-14 " style="padding-top: 30px; padding-bottom:30px;margin-bottom: 20px;">
    <div class="container">
        <div class="row">
            <div class="offset-lg-2 col-lg-8 col-md-12 col-12 text-center">
                <!-- <span class="fs-4 text-warning ls-md text-uppercase fw-semi-bold">
                    get things done
                </span> -->
                <!-- heading  -->
                <h2 class="display-3 mt-4 mb-3 text-black fw-bold">
                    Want to see your brand performing better?
                </h2>
                <!-- para  -->
                <a class="btn-animation border dark" href="/blogs" data-animation="animated slideInUp">Show Me How <i class="arrow_right"></i></a>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\kabos\OneDrive\Desktop\react\blank-web\resources\views\components\brand-cta.blade.php ENDPATH**/ ?>