<div class="pt-14 bg-dark" style="padding-top: 30px; padding-bottom:30px;">
    <div class="container">
        <div class="row">
            <div class="offset-lg-2 col-lg-8 col-md-12 col-12 text-center">
                <!-- <span class="fs-4 text-warning ls-md text-uppercase fw-semi-bold">
                    get things done
                </span> -->
                <!-- heading  -->
                <h2 class="display-3 mt-4 mb-3 text-white fw-bold">
                    Need a support in marketing?
                </h2>
                <!-- para  -->
                <p class="lead text-white-50 px-lg-8 mb-6">
                    Just try it out! You’ll fall in love
                </p>
                <a class="btn-animation border light" href="/contact" data-animation="animated slideInUp">Let's Chat <i class="arrow_right"></i></a>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\kabos\OneDrive\Desktop\react\blank-web\resources\views/components/cta.blade.php ENDPATH**/ ?>