
<?php $__env->startSection('title','Admin Add Blog'); ?>
<?php $__env->startSection('content'); ?>

<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Add Blog</h3>
            </div>

            <div class="title_right">
                <div class="col-md-5 col-sm-5  form-group pull-right top_search">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search for...">
                        <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 ">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Updating blog content<small>fill in the form</small></h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <br />
                        <form action="/admin/blog/<?php echo e($blog->id); ?>" method="POST" enctype="multipart/form-data" class="form-horizontal form-label-left">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group row ">
                                <label class="control-label col-md-3 col-sm-3 ">Blog title</label>
                                <div class="col-md-9 col-sm-9 ">
                                    <input type="text" class="form-control" id="title" name="title" value="<?php echo e($blog->title); ?>" required placeholder="enter blog title">
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3 col-sm-3 ">Blog slug </label>
                                <div class="col-md-9 col-sm-9 ">
                                    <input type="text" class="form-control" id="slug" name="slug" value="<?php echo e($blog->slug); ?>" placeholder="blog slug">
                                    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <!-- <div class="form-group row">
                                    <label class="control-label col-md-3 col-sm-3 ">Select</label>
                                    <div class="col-md-9 col-sm-9 ">
                                        <select class="form-control">
                                            <option>Choose option</option>
                                            <option>Option one</option>
                                            <option>Option two</option>
                                            <option>Option three</option>
                                            <option>Option four</option>
                                        </select>
                                    </div>
                                </div> -->
                            <div class="form-group row">
                                <label class="control-label col-md-3 col-sm-3 ">Select Category</label>
                                <div class="col-md-9 col-sm-9 ">
                                    <select class="select2_single form-control" id="blog_category" name="blog_category" value="<?php echo e($blog->blog_category); ?>" required tabindex="-1">
                                        <option></option>
                                        <option value="branding">Branding</option>
                                        <option value="design">Design</option>
                                        <option value="content_creation">Content Creation</option>
                                        <option value="web">Web</option>
                                        <option value="socialmedia">social media</option>
                                    </select>
                                    <?php $__errorArgs = ['blog_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="control-group row">
                                <label class="control-label col-md-3 col-sm-3 ">Input Tags</label>
                                <div class="col-md-9 col-sm-9 ">
                                    <input id="blog_tags" name="blog_tags" required type="text" class="tags form-control" value="<?php echo e($blog->blog_tags); ?>" />
                                    <div id="suggestions-container" style="position: relative; float: left; width: 250px; margin: 10px;"></div>
                                </div>
                            </div>
                            <div class="control-group row">
                                <label class="control-label col-md-3 col-sm-3 " for="image" value="<?php echo e($blog->image); ?>">image</label>
                                <div class="col-md-9 col-sm-9 ">
                                    <input type="file" class="form-control" id="image" name="image" required>
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div><!-- End .form-group -->
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Short description</h2>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                <textarea class="form-control" id="short_description" name="short_description" rows="3"></textarea>
                                    <?php $__errorArgs = ['short-description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Enter Body Content</h2>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <textarea id="summernote" class="summernote" name="content" required><?php echo e($blog->content); ?></textarea>
                                    <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="ln_solid"></div>
                            <div class="form-group">
                                <div class="col-md-9 col-sm-9  offset-md-3">
                                    <button type="submit" class="btn btn-success">Submit</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /page content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kabos\OneDrive\Desktop\react\blank-web\resources\views\admin\edit_blog.blade.php ENDPATH**/ ?>