<!-- footer content -->
<footer>
    <div class="pull-right">
        <p>&copy; Copyright <?php echo date("Y"); ?>. All Rights Reserved</p>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content --><?php /**PATH C:\Users\kabos\OneDrive\Desktop\react\blank-web\resources\views\admin\footer.blade.php ENDPATH**/ ?>