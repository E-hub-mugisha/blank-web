<a href="/">
    <img src="assets/img/blank-logo.jpg" alt="">
</a>
<?php /**PATH C:\Users\kabos\OneDrive\Desktop\react\blank-web\resources\views\components\authentication-card-logo.blade.php ENDPATH**/ ?>