
<?php $__env->startSection('title','Admin Blog'); ?>
<?php $__env->startSection('content'); ?>

<!-- page content -->
<div class="right_col" role="main">
    <div class="">

        <div class="page-title">
            <div class="title_left">
                <h3>Inbox Design <small>Some examples to get you started</small></h3>
            </div>

            <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search for...">
                        <span class="input-group-btn">
                            <button class="btn btn-secondary" type="button">Go!</button>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2><?php echo e($testimonial->names); ?>'s<small>testimonial</small></h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="row">
                            <!-- CONTENT MAIL -->
                            <div class="col-sm-9 mail_view">
                                <div class="inbox-body">
                                    <div class="mail_heading row">
                                        <div class="col-md-8">
                                            <div class="btn-group">
                                                <a href="/admin/testimonial/<?php echo e($testimonial->id); ?>/edit" class="btn btn-sm btn-default" type="button" data-placement="top" data-toggle="tooltip" data-original-title="Print"><i class="fa fa-print"></i></a>
                                                <form action="/admin/testimonial/<?php echo e($testimonial->id); ?>" method="post" class="d-inline">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo method_field('DELETE'); ?>
                                                    <button onclick="confirm('are you sure, you want to delete this!') || event.stopImmediatePropagation()" class="btn btn-sm btn-default" type="submit" data-placement="top" data-toggle="tooltip" data-original-title="Trash"><i class="fa fa-trash-o"></i></button>
                                                </form>
                                            </div>
                                        </div>
                                        <div class="col-md-4 text-right">
                                            <p class="date"><?php echo e($testimonial->created_at); ?></p>
                                        </div>
                                        <div class="col-md-12">
                                            <h4> <?php echo e($testimonial->names); ?></h4>
                                        </div>
                                    </div>
                                    <div class="view-mail">
                                        <p>
                                            <?php echo $testimonial->review; ?>

                                        </p>
                                    </div>
                                </div>

                            </div>
                            <!-- /CONTENT MAIL -->
                            <div class="col-sm-3 mail_list_column">
                                <button id="compose" class="btn btn-sm btn-success btn-block" type="button">Others</button>
                                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="/admin/testimonial-single/<?php echo e($testimonial->id); ?>">
                                    <div class="mail_list">
                                        <div class="left">
                                            <i class="fa fa-circle"></i> <i class="fa fa-edit"></i>
                                        </div>
                                        <div class="right">
                                            <h3><?php echo e($testimonial->names); ?>'s <small>testimonial</small></h3>
                                            <p>Created on <?php echo e($testimonial->created_at); ?></p>
                                        </div>
                                    </div>
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <!-- /MAIL LIST -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /page content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kabos\OneDrive\Desktop\react\blank-web\resources\views\admin\testimonial_single.blade.php ENDPATH**/ ?>