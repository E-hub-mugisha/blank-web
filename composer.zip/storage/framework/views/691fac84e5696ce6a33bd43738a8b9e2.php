<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name', 'Blank')); ?></title>

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="blank">

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/fav.png')); ?>" type="image/x-icon">
    <link rel="icon" href="<?php echo e(asset('assets/img/fav.png')); ?>" type="image/x-icon" />

    <!-- ========== Start Stylesheet ========== -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/themify-icons.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/flaticon-set.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/elegant-icons.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>" rel="stylesheet" />
    <!-- <link href="<?php echo e(asset('assets/css/animate.css')); ?>" rel="stylesheet" /> -->
    <link href="<?php echo e(asset('assets/css/bootsnav.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <!-- ========== End Stylesheet ========== -->
    <!-- Fonts -->
    
    <!-- Scripts -->
    
</head>

<body class="blue">
    
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="<?php echo e(asset('assets/js/jquery-1.12.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.appear.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/modernizr.custom.13711.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/progress-bar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/imagesloaded.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/count-to.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/YTPlayer.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootsnav.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/easy-pie-chart.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pie-chart-active.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
</body>

</html><?php /**PATH C:\Users\kabos\OneDrive\Desktop\react\blank-web\resources\views\layouts\guest.blade.php ENDPATH**/ ?>