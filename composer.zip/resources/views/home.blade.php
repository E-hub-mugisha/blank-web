@section('title', 'Home')

@include('components.header')    