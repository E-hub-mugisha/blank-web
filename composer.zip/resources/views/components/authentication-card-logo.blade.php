<a href="/">
    <img src="assets/img/blank-logo.jpg" alt="">
</a>
