<!-- Star Testimonials
    ============================================= -->

<div class="testimonials-area default-padding-bottom bg-gray">
    <div class="container">
        <div class="testimonial-items text-center">
            <div class="row">
                <div class="col-lg-5"></div>
                <div class="col-lg-7 mt-5">
                    <div class="heading">
                        <h2>10,000+ Happy Customers</h2>
                    </div>
                    <div class="testimonials-carousel owl-carousel owl-theme">
                        <div class="item">
                            <p>
                                Ashamed no inhabit ferrars it ye besides resolve. Own judgment directly few trifling. Elderly as pursuit at regular do parlors. Rank what has into fond pursuit at regular.
                            </p>
                            <!-- <div class="thumb-box">
                                <div class="thumb">
                                    <img src="assets/img/teams/1.jpg" alt="Thumb">
                                </div>
                            </div> -->
                            <h5>Jonath Dark</h5>
                            <span>Senior Developer</span>
                        </div>
                        <div class="item">
                            <p>
                                Ashamed no inhabit ferrars it ye besides resolve. Own judgment directly few trifling. Elderly as pursuit at regular do parlors. Rank what has into fond pursuit at regular.
                            </p>
                            <!-- <div class="thumb-box">
                                <div class="thumb">
                                    <img src="assets/img/teams/2.jpg" alt="Thumb">
                                </div>
                            </div> -->
                            <h5>Jonath Dark</h5>
                            <span>Senior Developer</span>
                        </div>
                        <div class="item">
                            <p>
                                Ashamed no inhabit ferrars it ye besides resolve. Own judgment directly few trifling. Elderly as pursuit at regular do parlors. Rank what has into fond pursuit at regular.
                            </p>
                            <!-- <div class="thumb-box">
                                <div class="thumb">
                                    <img src="assets/img/teams/3.jpg" alt="Thumb">
                                </div>
                            </div> -->
                            <h5>Jonath Dark</h5>
                            <span>Senior Developer</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Testimonials -->