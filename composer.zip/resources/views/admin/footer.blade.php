<!-- footer content -->
<footer>
    <div class="pull-right">
        <p>&copy; Copyright <?php echo date("Y"); ?>. All Rights Reserved</p>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->