<x-mail::message>  

# New newsletter subscription from {{ $newsData['email']}}

Thanks,<br>
{{ config('app.name') }}
</x-mail::message>