<?php return array (
  'admin.admin-add-blog-component' => 'App\\Http\\Livewire\\Admin\\AdminAddBlogComponent',
);